# Astropy Project Governance

Please visit our website to learn more about the [Astropy Team](http://www.astropy.org/team.html).